#!/bin/bash
python3 knn.py $1 $2
exit 0
